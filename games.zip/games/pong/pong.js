const canvas = document.getElementById('pongCanvas');
const ctx = canvas.getContext('2d');
const restartButton = document.getElementById('restartButton');
const countdown = document.getElementById('countdown');

let canvasWidth = canvas.width;
let canvasHeight = canvas.height;
const paddleWidth = 10;
const paddleHeight = 100;
const ballRadius = 10;

let wPressed = false;
let sPressed = false;
let upArrowPressed = false;
let downArrowPressed = false;

let paddle1 = {
    x: 0,
    y: canvasHeight / 2 - paddleHeight / 2,
    width: paddleWidth,
    height: paddleHeight,
    color: "#FFF",
    dy: 5
};

let paddle2 = {
    x: canvasWidth - paddleWidth,
    y: canvasHeight / 2 - paddleHeight / 2,
    width: paddleWidth,
    height: paddleHeight,
    color: "#FFF",
    dy: 5
};

let ball = {
    x: canvasWidth / 2,
    y: canvasHeight / 2,
    radius: ballRadius,
    speed: 4,
    dx: 4,
    dy: 4,
    color: "#05EDFF"
};

function drawRect(x, y, w, h, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
}

function drawArc(x, y, r, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2, false);
    ctx.closePath();
    ctx.fill();
}

function resetBall() {
    ball.x = canvasWidth / 2;
    ball.y = canvasHeight / 2;
    ball.speed = 4;
    ball.dx = (Math.random() > 0.5 ? 1 : -1) * ball.speed;
    ball.dy = (Math.random() > 0.5 ? 1 : -1) * ball.speed;
}

function endGame(winner) {
    clearInterval(gameLoop);
    alert(winner + " wins!");
}

function update() {
    if (wPressed && paddle1.y > 0) {
        paddle1.y -= paddle1.dy;
    } else if (sPressed && paddle1.y < canvasHeight - paddle1.height) {
        paddle1.y += paddle1.dy;
    }

    if (upArrowPressed && paddle2.y > 0) {
        paddle2.y -= paddle2.dy;
    } else if (downArrowPressed && paddle2.y < canvasHeight - paddle2.height) {
        paddle2.y += paddle2.dy;
    }

    ball.x += ball.dx;
    ball.y += ball.dy;

    if (ball.y + ball.radius > canvasHeight || ball.y - ball.radius < 0) {
        ball.dy *= -1;
    }

    let player = (ball.x < canvasWidth / 2) ? paddle1 : paddle2;

    if (collision(ball, player)) {
        let collidePoint = ball.y - (player.y + player.height / 2);
        collidePoint = collidePoint / (player.height / 2);

        let angleRad = (Math.PI / 4) * collidePoint;
        let direction = (ball.x < canvasWidth / 2) ? 1 : -1;
        ball.dx = direction * ball.speed * Math.cos(angleRad);
        ball.dy = ball.speed * Math.sin(angleRad);
        ball.speed += 0.5; // Increase the ball speed after every paddle hit
    }

    if (ball.x - ball.radius < 0) {
        endGame("Player 2");
    } else if (ball.x + ball.radius > canvasWidth) {
        endGame("Player 1");
    }
}

function collision(b, p) {
    b.top = b.y - b.radius;
    b.bottom = b.y + b.radius;
    b.left = b.x - b.radius;
    b.right = b.x + b.radius;

    p.top = p.y;
    p.bottom = p.y + p.height;
    p.left = p.x;
    p.right = p.x + p.width;

    return p.left < b.right && p.top < b.bottom && p.right > b.left && p.bottom > b.top;
}

function game() {
    update();
    render();
}

function render() {
    ctx.clearRect(0, 0, canvasWidth, canvasHeight);
    drawRect(0, 0, canvasWidth, canvasHeight, "#000");
    drawRect(paddle1.x, paddle1.y, paddle1.width, paddle1.height, paddle1.color);
    drawRect(paddle2.x, paddle2.y, paddle2.width, paddle2.height, paddle2.color);
    drawArc(ball.x, ball.y, ball.radius, ball.color);
}

document.addEventListener('keydown', function(event) {
    switch (event.keyCode) {
        case 87:
            wPressed = true;
            break;
        case 83:
            sPressed = true;
            break;
        case 38:
            upArrowPressed = true;
            break;
        case 40:
            downArrowPressed = true;
            break;
    }
});

document.addEventListener('keyup', function(event) {
    switch (event.keyCode) {
        case 87:
            wPressed = false;
            break;
        case 83:
            sPressed = false;
            break;
        case 38:
            upArrowPressed = false;
            break;
        case 40:
            downArrowPressed = false;
            break;
    }
});

restartButton.addEventListener('click', function() {
    document.location.reload();
});

let gameLoop;

function startCountdown() {
    let counter = 5;
    const countdownInterval = setInterval(() => {
        countdown.innerText = counter;
        counter--;
        if (counter < 0) {
            clearInterval(countdownInterval);
            countdown.style.display = 'none';
            gameLoop = setInterval(game, 1000 / 60); // Start the game loop
        }
    }, 1000);
}

function resizeCanvas() {
    const aspectRatio = 3 / 2;
    const width = window.innerWidth * 0.9;
    const height = width / aspectRatio;
    canvas.width = width;
    canvas.height = height;
    canvasWidth = width;
    canvasHeight = height;

    // Update paddle and ball positions
    paddle1.height = canvasHeight / 4;
    paddle2.height = canvasHeight / 4;
    paddle2.x = canvasWidth - paddleWidth;
    ball.radius = canvasHeight / 40;

    // Reset the ball to ensure it stays within bounds
    resetBall();
}

window.addEventListener('resize', resizeCanvas);
resizeCanvas();
startCountdown(); // Start the countdown timer when the page loads
